# service-extract-reports

Service to extract all sql reports in SQL folder and convert result into a CSV file per report
