require('dotenv').config();
const path = require('path');
const moment = require('moment');
const Log4js = require('log4js');
const { mssqlConn } = require('@nelreina/node-sequelize');
const S = require('string');
const argv = require('minimist')(process.argv.slice(2));

S.extendPrototype();

const DataExtract = require('./data-extract');
Log4js.configure('./log4js.json');

const logger = Log4js.getLogger();

const mssql = mssqlConn();

logger.info('Start creating file...');
const { json, cp, lp } = argv;
const ext = json ? 'json' : 'csv';
let periodPath = '';
if (cp) {
  periodPath = moment().format('/YYYY/MM');
}
if (lp) {
  periodPath = moment()
    .subtract(1, 'months')
    .format('/YYYY/MM');
}

const DIR_OUTPUT =
  process.env.DIR_OUTPUT || path.dirname(process.execPath) + '/output';
const DIR_SQLSTMTS =
  process.env.DIR_SQLSTMTS || path.dirname(process.execPath) + '/sql';

const options = { DIR_OUTPUT, DIR_SQLSTMTS, ext, periodPath };

(async () => {
  const de = new DataExtract(mssql, options);

  de.on('log', data => logger.info(data));
  try {
    await de.run();
  } catch (error) {
    logger.error(error);
  }
  // logger.info(ret);
  process.exit(0);
})();
