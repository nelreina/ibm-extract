require('dotenv').config();
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const cors = require('cors');
const Log4js = require('log4js');
const http = require('http');
const log4js = require('@nelreina/node-log4js');

const PORT = process.env.PORT;

const routes = require('./routes');
const logger = log4js('ssis-service', { file: true });

const publicPath = path.resolve(__dirname, '../public');

const app = express();
app.use(cors());
app.use(express.static(publicPath));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(Log4js.connectLogger(logger, { level: 'debug' }));
const server = http.Server(app);
const io = require('socket.io')(server);

io.on('connection', socket => {
  logger.debug('New client connected: ', socket.id);
  logger.debug('Total Clients connected: ', io.engine.clientsCount);
});

(async () => {
  logger.info('Starting server...');
  routes(app, logger, { io });
  app.post('/api/*', (req, res) =>
    res.status(401).send('Not Authorized to call this resource')
  );
  app.get('*', (req, res) => {
    res.sendFile(path.resolve(publicPath, 'index.html'));
  });
  server.listen(PORT, () => {
    logger.info(`App is running on port ${PORT}`);
  });
})().catch(err => logger.error(err.message));
