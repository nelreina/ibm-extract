const express = require('express');
const { login } = require('@ibis/module-users');

const api = express.Router();

module.exports = logger => {
  api.post('/', async (req, res) => {
    const { username, password } = req.body;
    logger.info(`Loggin attempt by "${username}"`);
    try {
      const user = await login({ username, password });
      res.send(user);
    } catch (error) {
      res.status(401).send(error.message);
    }
  });

  return api;
};
