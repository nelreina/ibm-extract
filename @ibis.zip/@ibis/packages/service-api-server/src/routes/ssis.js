const express = require('express');
const SSIS = require('@ibis/module-ssis');
const api = express.Router();

module.exports = (logger, connections) => {
  const ssis = new SSIS(connections, logger);
  logger.info('Initialize SSIS project');
  ssis.init();
  const handleError = (error, res) => {
    const { name, message } = error;
    logger.error(JSON.stringify({ name, message }));
    res.status(503).send({ name, message });
  };
  api.get('/env', (req, res) => {
    try {
      res.send(ssis.getEnvVariables());
    } catch (error) {
      handleError(error, res);
    }
  });
  api.post('/env', async (req, res) => {
    try {
      const response = await ssis.saveEnvVariables(req.body);
      res.send(response);
    } catch (error) {
      handleError(error, res);
    }
  });
  api.get('/execution/status', (req, res) => {
    res.send(ssis.getExecutionStatus());
  });
  api.get('/execution/history', async (req, res) => {
    try {
      const response = await ssis.getExecutionHistory();
      res.send(response);
    } catch (error) {
      handleError(error, res);
    }
  });
  api.get('/execution/errors/:id', async (req, res) => {
    try {
      const response = await ssis.getEventErrors(req.params.id);
      res.send(response);
    } catch (error) {
      handleError(error, res);
    }
  });
  api.post('/execution/hook', (req, res) => {
    const response = ssis.setExecutionDetails(req.body);
    res.send(response);
  });
  api.post('/execution/:pck', async (req, res) => {
    const { username } = req.body;
    try {
      const response = await ssis.execute(req.params.pck, username);
      res.send(response);
    } catch (error) {
      handleError(error, res);
    }
  });

  return api;
};
