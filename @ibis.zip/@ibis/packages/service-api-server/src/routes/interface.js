const express = require('express');
const Interface = require('../lib/InterfaceSettings');

const api = express.Router();

module.exports = logger => {
  const interface = new Interface(logger);
  logger.info('Gathering Interface Settings');

  api.get('/settings', (req, res) => {
    res.send(interface.getSettings());
  });

  return api;
};
