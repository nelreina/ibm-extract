const Sequelize = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  const User = sequelize.define(
    'gl_users',
    {
      username: {
        type: DataTypes.STRING,
        allowNull: false
      },
      displayName: {
        type: DataTypes.STRING,
        allowNull: false
      },
      email: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: { isEmail: true }
      },
      role: {
        type: DataTypes.STRING,
        allowNull: false,
        defaultValue: 'exec'
      },
      active: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true
      },
      logginAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: Sequelize.NOW
      },
      lastLogginAt: {
        type: DataTypes.DATE
      }
    },
    {
      paranoid: true,
      freezeTableName: true
    }
  );
  User.exists = async username => {
    const ret = await User.findOne({ where: { username } });
    if (ret) return true;
    else return false;
  };
  User.findByUsername = async username => {
    return await User.findOne({ where: { username } });
  };

  return User;
};
