require('dotenv').config();
const User = require('./index');
(async () => {
  const user = await User.login({ username: 'nreina', password: '' });
  console.info(user);
  process.exit(0);
})().catch(err => console.error(err.message));
