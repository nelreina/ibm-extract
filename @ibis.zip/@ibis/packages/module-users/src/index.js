require('dotenv').config();
const Log4js = require('log4js');

Log4js.configure('./log4js.json');
const logger = Log4js.getLogger();

const models = require('./models');
const { gl_users: User } = models;
const { login: _ADLogin } = require('@ibis/module-active-directory');
(async () => {
  await models.sequelize.sync();
})();

const _handleGLUsers = async adUser => {
  if (await User.exists(adUser.username)) {
    const user = await User.findByUsername(adUser.username);
    if (user.active) {
      user.lastLogginAt = user.logginAt;
      user.logginAt = new Date();
      return (await user.save()).toJSON();
    } else {
      logger.error(`User "${adUser.username}" is inactive`);
      throw new Error(`You are not allowed to use this system!`);
    }
  } else {
    const createUser = await User.create(adUser);
    const user = await createUser.save();
    return user.toJSON();
  }
};

const login = async credentials => {
  const { username, password } = credentials;
  try {
    const adUser = await _ADLogin({ username, password });
    const user = await _handleGLUsers(adUser);
    return { user, isAuthenticated: true };
  } catch (error) {
    throw error;
  }
};

module.exports = { login };
