import React from 'react';
import List from '@nelreina/react-list';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';

import { userSelector } from '../store/selectors';

const DetailsList = ({ item }) => {
  if (item.label === 'Password') return '';

  return (
    <li className="conn-label">
      <label className="text-mute">{item.label}</label>

      <span>{item.value}</span>
    </li>
  );
};
const SmallList = ({ item }) => {
  if (item.label === 'Password') return '';

  return <span>{item.value}</span>;
};

const ConnectionItem = ({ item, path, ssis, user: { isAdmin } }) => {
  const lt = ssis.isExecuting ? 'text-light' : '';
  return (
    <div className={['connection-card', lt].join(' ')}>
      <h5 className="title">
        <span>{item.label}</span>
        {isAdmin && (
          <span className="config-icon">
            <Link to={`/configure/${path}`}>
              <i className="fa fa-wrench fa-1x" />
            </Link>
          </span>
        )}
      </h5>
      <small>{item.vendor}</small>
      <ul className="list">
        <span className="details">
          <List of={DetailsList} iterator={item.data} />
        </span>
        <div className="small-list">
          <List of={SmallList} iterator={item.data} />
        </div>
      </ul>
    </div>
  );
};

export default connect(state => ({
  ssis: state.ssis,
  user: userSelector(state)
}))(ConnectionItem);
