import React from 'react';

const ButtonExecute = ({ name, pack, execute, isExecuting, className }) => {
  return (
    <button
      className={`btn ${className} ${isExecuting && 'disabled'}`}
      onClick={() => execute(pack)}
      disabled={isExecuting}
    >
      {name}
    </button>
  );
};

export default ButtonExecute;
