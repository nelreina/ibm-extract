import React from 'react';
import StatusIcon from './StatusIcon';
const Status = ({ text }) => {
  if (!text) return '';
  const [descr, id] = text.split('#');
  console.info(descr);
  return (
    <span>
      <StatusIcon status={parseInt(id, 0)} />
    </span>
  );
};

export default Status;
