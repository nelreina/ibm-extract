import React from 'react';
import { isEmpty } from 'lodash';
import List from '@nelreina/react-list';
import styled from 'styled-components';

import Status from '../components/Status';
import Spinner from './Spinner';
const StartingJob = styled.div`
  padding: 1em;
  text-align: center;
  font-size: 2em;
  color: palevioletred;
  &::after {
    content: ' Starting the job';
  }
`;

const Wrapper = styled.div`
  margin: 1em 0;
`;

const ExecItem = ({ item, subject }) => (
  <div className="execution-item">
    <span>
      <Status text={item.status} /> [{item.source
        ? item.source.toUpperCase()
        : ''}].{subject}
    </span>
    <div>{item.desc && <span>{item.desc}</span>} </div>
  </div>
);

const ExecutionDetails = ({ details, isExecuting }) => {
  return (
    <Wrapper>
      {isEmpty(details) && isExecuting ? (
        <StartingJob>
          <Spinner size="1x" />
        </StartingJob>
      ) : (
        <div className="execution-details">
          <List of={ExecItem} iterator={details} keyname="subject" />
        </div>
      )}
    </Wrapper>
  );
};

export default ExecutionDetails;
