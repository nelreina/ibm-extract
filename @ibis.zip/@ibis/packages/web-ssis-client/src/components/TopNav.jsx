import React from 'react';
import { Link } from 'react-router-dom';

const TopNav = ({ user }) => {
  return (
    <nav className="navbar navbar-dark bg-dark">
      <span className="navbar-brand mb-0 h1">Greenlight SSIS ETL</span>
      {user.username && (
        <span className="navbar-text">
          <Link to="/profile">
            {user.displayName} ({user.username})
          </Link>
        </span>
      )}
    </nav>
  );
};

export default TopNav;
