import { ReduxFormClass as Form } from '@nelreina/react-redux-form';
import { store } from '../store';
import { initFormSelector } from '../store/selectors';
export default id => {
  console.info(id);
  const settings = initFormSelector(store.getState());
  const form = settings[id];
  if (!form) return undefined;
  const SettingsForm = new Form('SettingsForm', form.fields, form.initialValues)
    .button('Save Configuration', 'btn btn-success btn-block')
    .getComponent();

  return SettingsForm;
};
