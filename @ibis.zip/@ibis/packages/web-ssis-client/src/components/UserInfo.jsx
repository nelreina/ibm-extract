import React from 'react';
import styled from 'styled-components';
import Moment from './Moment';
const Wrapper = styled.div`
  margin-bottom: 1em;
`;
const InfoRow = styled.div`
  display: grid;
  grid-template-columns: 1fr 2fr;
`;

const UserInfo = ({ username, displayName, email, role, lastLogginAt }) => {
  return (
    <Wrapper>
      <InfoRow>
        <span>Username</span>
        <span>{username}</span>
      </InfoRow>
      <InfoRow>
        <span>Fullname</span>
        <span>{displayName}</span>
      </InfoRow>
      <InfoRow>
        <span>Email Address</span>
        <span>{email}</span>
      </InfoRow>
      <InfoRow>
        <span>Role</span>
        <span>{role}</span>
      </InfoRow>
      <InfoRow>
        <span>Last Loggin</span>
        <span>
          <Moment>{lastLogginAt}</Moment>
        </span>
      </InfoRow>
    </Wrapper>
  );
};

export default UserInfo;
