import React from 'react';
import Moment from './Moment';
const Footer = ({ user }) => {
  return (
    <footer className="footer">
      <div className="container">
        <small className="text-muted">&copy; 2018 IBIS Management</small>
        {user.username && (
          <small className="text-muted">
            Previous loggin <Moment>{user.lastLogginAt}</Moment>{' '}
          </small>
        )}
        <small className="text-muted">
          Version: {process.env.REACT_APP_VERSION}
        </small>
      </div>
    </footer>
  );
};

export default Footer;
