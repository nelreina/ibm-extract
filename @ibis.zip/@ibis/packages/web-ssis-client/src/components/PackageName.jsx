// import React from 'react';
import S from 'string';
const PackageName = ({ name }) => {
  return name
    ? S(name.replace('.dtsx', ''))
        .humanize()
        .titleCase().s
    : '';
};

export default PackageName;
