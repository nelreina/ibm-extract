import React from 'react';
import ConnectionItem from './ConnectionItem';
import List from '@nelreina/react-list';

const Connections = ({ display }) => {
  return (
    <div className=" connections">
      <List of={ConnectionItem} iterator={display} keyname="path" />
    </div>
  );
};

export default Connections;
