// import React from 'react';
import moment from 'moment';
const Duration = ({ seconds = 0 }) => {
  return `${moment.utc(seconds * 1000).format('HH:mm:ss')}`;
};

export default Duration;
