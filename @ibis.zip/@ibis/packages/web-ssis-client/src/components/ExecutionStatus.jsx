import React from 'react';
import Icon from '../components/StatusIcon';
import PackageName from '../components/PackageName';
import Duration from './Duration';
import Moment from './Moment';
import { isEmpty } from 'lodash';
const ExecutionStatus = ({ isExecuting, executionStatus }) => {
  if (isEmpty(executionStatus)) return '';
  const {
    execution_id,
    package_name,
    start_time,
    status,
    status_desc,
    elapsed_time_min,
    params
  } = executionStatus;
  const fail = status === 4 ? 'border-danger text-danger' : '';
  const success = status === 7 ? 'border-success text-success' : '';
  const execute = isExecuting ? 'bg-warning text-white' : '';
  return (
    <div className={['card', fail, success, execute].join(' ')}>
      <h6 className="card-header">
        {isExecuting ? 'Running...' : 'Last Run'} - (id: {execution_id})
      </h6>
      <div className="card-body execution-status">
        <span>
          <Moment format="dddd DD MMMM YYYY">{start_time}</Moment>
        </span>
        <span>{params && params.pUsername}</span>
        <span>
          <PackageName name={package_name} />{' '}
        </span>
        <span>
          <Icon status={status} /> {status_desc}
        </span>
        <span>
          Duration: <Duration seconds={elapsed_time_min} />
        </span>
      </div>
    </div>
  );
};

export default ExecutionStatus;
