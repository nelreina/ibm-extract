import React from 'react';

const Spinner = ({ size = '3x' }) => {
  return <i className={`fa fa-spinner fa-spin fa-${size} fa-fw`} />;
};

export default Spinner;
