import React from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';

const Wrapper = styled(Link)`
  display: block;
  margin-bottom: 0.5em;
  align-self: flex-start;
`;
const BackLink = () => (
  <Wrapper to="/">
    <i className="fa fa-backward" /> Go Back
  </Wrapper>
);

export default BackLink;
