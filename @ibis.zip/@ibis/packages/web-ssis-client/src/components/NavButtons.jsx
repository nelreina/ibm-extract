import React from 'react';
import { Link } from 'react-router-dom';

import ButtonExecute from './ButtonExecute';

const NavButtons = props => {
  return (
    <div className="nav-buttons">
      <ButtonExecute
        name="START INTERFACE JOB"
        className="btn-primary"
        pack="Interface-job"
        {...props}
      />
      <ButtonExecute
        name="Export Greenlight File"
        className="btn-secondary"
        pack="Export-Greenlight-File"
        {...props}
      />
      <ButtonExecute
        name="Extract Reports"
        className="btn-light"
        pack="Extract-Reports"
        {...props}
      />

      <Link className="btn btn-link" to="/history">
        Show Execution History
      </Link>
    </div>
  );
};

export default NavButtons;
