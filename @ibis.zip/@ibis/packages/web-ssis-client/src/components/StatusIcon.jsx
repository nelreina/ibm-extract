import React from 'react';
import Spinner from './Spinner';
const StatusIcon = ({ status }) => {
  if (status === 2 || status === 5 || status === 101) {
    return <Spinner size="1x" />;
  }
  if (status === 7) {
    return <i className="fa fa-check-circle text-success" />;
  }

  return <i className="fa fa-exclamation-circle text-danger" />;
};

export default StatusIcon;
