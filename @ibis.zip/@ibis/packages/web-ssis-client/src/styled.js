import styled from 'styled-components';
import classnames from 'classnames';

export const LoginForm = styled.div``;
const btn = props =>
  classnames(
    'btn',
    { 'btn-primary': props.primary },
    { 'btn-danger': props.red },
    { 'btn-success': props.green },
    { 'btn-dark': props.black },
    { 'btn-block': props.block },
    { 'btn-block': props.block }
  );
export const Button = styled.button.attrs({
  className: props => btn(props)
})``;
