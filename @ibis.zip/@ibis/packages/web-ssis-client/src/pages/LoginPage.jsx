import React from 'react';
import { Login } from '@nelreina/react-route';
import { LoginFormUserName as UsernameForm } from '@nelreina/react-redux-form';
import { authActions } from '@nelreina/web-redux';
import { connect } from 'react-redux';
import Spinner from '../components/Spinner';

import styled from 'styled-components';

const LoginForm = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  > form {
    margin-top: 100px;
    width: 250px;
    border: 1px solid #ddd;
    padding: 1em;
  }
`;
const ErrMessage = styled.div`
  color: red;
`;
const Info = styled.div`
  color: rgba(0, 101, 254, 1);
  /* text-align: center; */
`;

const LoginPage = ({ auth, location, login }) => {
  return (
    <LoginForm>
      <Login auth={auth} location={location}>
        <UsernameForm action={login} loading={auth.inprogress} />
        {auth.message && <ErrMessage>{auth.message}</ErrMessage>}
        {auth.inprogress && (
          <Info>
            Loggin in <Spinner size="1x" />{' '}
          </Info>
        )}
      </Login>
    </LoginForm>
  );
};

export default connect(
  s => s,
  authActions
)(LoginPage);
