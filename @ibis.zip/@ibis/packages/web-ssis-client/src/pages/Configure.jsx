import React, { Component } from 'react';
import { Link, Redirect } from 'react-router-dom';
import { connect } from 'react-redux';

import createSettingForm from '../components/createSettingForm';
import * as actions from '../store/reducers/env';
import { userSelector } from '../store/selectors';

class Configure extends Component {
  constructor(props) {
    super(props);
    this._form = createSettingForm(props.match.params.id);
  }
  save = async values => {
    await this.props.postEnv(values);
    this.props.history.push('/');
  };
  render() {
    const {
      ssis: { isExecuting },
      user: { isAdmin }
    } = this.props;
    if (!this._form || isExecuting || !isAdmin) {
      return <Redirect to="/" />;
    }
    const SettingsForm = this._form;
    const label = this.props.settings[this.props.match.params.id].label;
    return (
      <div className="configure">
        <h4 className="text-center">{label}</h4>
        <SettingsForm action={this.save} />

        <Link className="btn btn-link btn-block" to="/">
          Cancel
        </Link>
      </div>
    );
  }
}

export default connect(
  state => ({
    settings: state.app.settings,
    ssis: state.ssis,
    user: userSelector(state)
  }),
  actions
)(Configure);
