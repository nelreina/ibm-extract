import React from 'react';
import { connect } from 'react-redux';
import styled from 'styled-components';
import { userSelector } from '../store/selectors';

import { authActions } from '@nelreina/web-redux';
import BackLink from '../components/BackLink';
import UserInfo from '../components/UserInfo';
import { Button } from '../styled';

const Wrapper = styled.div`
  display: flex;
  align-items: center;
  flex-direction: column;
  margin-top: 1em;
  justify-content: center;
`;
const Box = styled.div`
  display: flex;
  align-items: center;
  flex-direction: column;
  border: 1px #ddd solid;
  width: 50%;
  border-radius: 0.5em;
  padding: 1em;
`;

const Profile = ({ user, logout, history }) => {
  return (
    <Wrapper>
      <h4>Profile</h4>
      <BackLink />
      <Box>
        <UserInfo {...user} />
        <Button
          red
          onClick={() => {
            logout();
            history.push('/');
          }}
        >
          Logout
        </Button>
      </Box>
    </Wrapper>
  );
};

export default connect(
  state => ({
    user: userSelector(state)
  }),
  authActions
)(Profile);
