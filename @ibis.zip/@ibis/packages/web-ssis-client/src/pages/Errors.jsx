import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Redirect } from 'react-router-dom';
import List from '@nelreina/react-list';
import { find } from 'lodash';

import BackLink from '../components/BackLink';
import * as actions from '../store/reducers/ssis';
import Moment from '../components/Moment';
import ExecutionStatus from '../components/ExecutionStatus';

const nowrap = { whiteSpace: 'nowrap' };

const ErrorRows = ({ item }) => (
  <tr className={item.status === 4 ? 'text-danger' : ''}>
    <td style={nowrap}>
      <Moment>{item.message_time}</Moment>
    </td>
    <td style={nowrap}>{item.execution_path}</td>
    <td>{item.message}</td>
  </tr>
);

class Errors extends Component {
  componentDidMount = async () => {
    if (this.props.historyData.length === 0) {
      await this.props.fetchHistory();
    }
    this.props.fetchErrors(this.props.match.params.executionId);
  };

  render() {
    if (this.props.isExecuting) {
      return <Redirect to="/" />;
    }
    const execution_id = parseInt(this.props.match.params.executionId, 0);

    const obj = find(this.props.historyData, { execution_id });

    return (
      <div>
        <h4>Job Execution Errors</h4>
        <BackLink />
        <ExecutionStatus executionStatus={obj} />
        <table style={{ marginTop: '1em' }} className="table">
          <thead className="thead-light">
            <tr>
              <th>Date/ Teme</th>
              <th>Execution</th>
              <th>Message</th>
            </tr>
          </thead>
          <tbody>
            <List of={ErrorRows} iterator={this.props.executionErrors} />
          </tbody>
        </table>
      </div>
    );
  }
}

const msp = state => ({
  executionErrors: state.ssis.executionErrors,
  historyData: state.ssis.history,
  isExecuting: state.ssis.isExecuting
});

export default connect(
  msp,
  actions
)(Errors);
