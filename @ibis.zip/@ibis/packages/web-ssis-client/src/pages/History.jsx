import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import List from '@nelreina/react-list';

import * as actions from '../store/reducers/ssis';
import Icon from '../components/StatusIcon';
import Moment from '../components/Moment';
import Duration from '../components/Duration';
import PackageName from '../components/PackageName';
import BackLink from '../components/BackLink';

const showErrorLink = status => {
  switch (status) {
    case 1:
    case 4:
      return true;
    default:
      return false;
  }
};

const HistItems = ({ item }) => (
  <tr>
    <td>
      <Moment date>{item.start_time}</Moment>
    </td>{' '}
    <td>{item.username || 'unknown'}</td>
    {showErrorLink(item.status) && (
      <td>
        <Link to={`/errors/${item.execution_id}`}>
          <PackageName name={item.package_name} />
        </Link>
      </td>
    )}
    {!showErrorLink(item.status) && (
      <td>
        <PackageName name={item.package_name} />
      </td>
    )}
    <td className="d-none d-lg-table-cell">
      <Moment time>{item.start_time}</Moment>
    </td>
    <td className="d-none d-lg-table-cell">
      <Moment time>{item.end_time}</Moment>
    </td>
    <td className="d-none d-lg-table-cell">
      <Duration seconds={item.elapsed_time_min} />
    </td>
    <td>
      <Icon status={item.status} /> {item.status_desc}
    </td>
    <td className="d-none d-sm-table-cell">{item.execution_id}</td>
  </tr>
);

class History extends Component {
  componentDidMount = () => {
    this.props.fetchHistory();
  };

  render() {
    return (
      <div>
        <h4>Job Execution History</h4>
        <BackLink />
        <table className="table">
          <thead className="thead-light">
            <tr>
              <th>Date</th>
              <th>User</th>
              <th>Package Name</th>
              <th className="d-none d-lg-table-cell">Start Time</th>
              <th className="d-none d-lg-table-cell">End Time</th>
              <th className="d-none d-lg-table-cell">Duration</th>
              <th>Status</th>
              <th className="d-none d-sm-table-cell">#</th>
            </tr>
          </thead>
          <tbody>
            <List of={HistItems} iterator={this.props.ssis.history} />
          </tbody>
        </table>
      </div>
    );
  }
}

export default connect(
  state => state,
  actions
)(History);
