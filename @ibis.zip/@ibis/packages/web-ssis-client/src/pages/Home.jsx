import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import { assign } from 'lodash';

import * as actionsEnv from '../store/reducers/env';
import * as actionsSsis from '../store/reducers/ssis';
import * as actionsApp from '../store/reducers/app';
import { userSelector } from '../store/selectors';

import Connections from '../components/Connections';
import NavButtons from '../components/NavButtons';
import ExecutionStatus from '../components/ExecutionStatus';
import ExecutionDetails from '../components/ExecutionDetails';
import { displaySettingsSelector } from '../store/selectors';

class Home extends Component {
  componentDidMount = async () => {
    if (this.props.auth.isAuthenticated) {
      await this.props.fetchSettings();
      this.props.fetchEnv();
      this.props.fetchExecutionStatus();
    }
  };

  render() {
    const { display, startExecution, ssis } = this.props;
    return (
      <Fragment>
        <NavButtons
          execute={startExecution}
          isExecuting={ssis.isExecuting | ssis.starting}
        />
        <ExecutionStatus {...ssis} />
        <ExecutionDetails
          details={ssis.executionDetails}
          isExecuting={ssis.isExecuting | ssis.starting}
        />
        <Connections display={display} />
      </Fragment>
    );
  }
}
const msp = state => ({
  display: displaySettingsSelector(state),
  ssis: state.ssis,
  auth: state.auth,
  user: userSelector(state)
});
const actions = assign({}, actionsEnv, actionsSsis, actionsApp);

export default connect(
  msp,
  actions
)(Home);
