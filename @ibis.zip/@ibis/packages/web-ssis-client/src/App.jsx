import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import { Switch, Route, withRouter } from 'react-router-dom';
import { PrivateRoute as Private } from '@nelreina/react-route';

import './App.css';
import { userSelector } from './store/selectors';

import Configure from './pages/Configure';
import Home from './pages/Home';
import LoginPage from './pages/LoginPage';
import History from './pages/History';
import Errors from './pages/Errors';
import Profile from './pages/Profile';
import TopNav from './components/TopNav';
import Footer from './components/Footer';

class App extends Component {
  render() {
    const { auth, user } = this.props;
    return (
      <Fragment>
        <div className="container">
          <TopNav user={user} />
          {/* <pre>{JSON.stringify(user, null, 2)}</pre> */}
          <div className="content">
            <Switch>
              <Route
                path="/login"
                render={({ location }) => <LoginPage location={location} />}
              />
              <Private auth={auth} exact path="/" component={Home} />
              <Private
                auth={auth}
                path="/configure/:id"
                component={Configure}
              />
              <Private
                auth={auth}
                path="/errors/:executionId"
                component={Errors}
              />
              <Private auth={auth} path="/history" component={History} />
              <Private auth={auth} path="/profile" component={Profile} />
            </Switch>
          </div>
        </div>
        <Footer user={user} />
      </Fragment>
    );
  }
}
const mps = state => ({
  auth: state.auth,
  user: userSelector(state)
});
export default withRouter(connect(mps)(App));
