import { assign } from 'lodash';

const FETCHING = '[env] FETCHING_ENV';
const FETCH_SUCCESS = '[env] FETCH_ENV_SUCCESS';
const FETCH_ERROR = '[env] FETCH_ENV_ERROR';
const POSTING = '[env] POSTING_ENV';
const POST_SUCCESS = '[env] POST_ENV_SUCCESS';
const POST_ERROR = '[env] POST_ENV_ERROR';

const initialState = { data: [] };

export const fetchEnv = () => async (dispatch, getState, api) => {
  dispatch({ type: FETCHING });
  try {
    const payload = await api.get('/ssis/env');
    dispatch({
      type: FETCH_SUCCESS,
      payload
    });
  } catch (error) {
    dispatch({
      type: FETCH_ERROR,
      payload: error
    });
  }
};
export const postEnv = values => async (dispatch, getState, api) => {
  dispatch({ type: POSTING });
  try {
    const payload = await api.post('/ssis/env', values);
    dispatch({
      type: POST_SUCCESS,
      payload
    });
    return true;
  } catch (error) {
    dispatch({
      type: POST_ERROR,
      payload: error
    });
    return false;
  }
};

export default (state = initialState, action) => {
  const { type, payload } = action;
  switch (type) {
    case FETCH_SUCCESS:
    case POST_SUCCESS:
      return assign({}, state, {
        error: false,
        fetching: false,
        data: payload
      });
    case FETCHING:
    case POSTING:
      return assign({}, state, { error: false, fetching: true });
    case FETCH_ERROR:
    case POST_ERROR:
      return assign({}, state, { error: true, message: payload, data: [] });

    default:
      return state;
  }
};
