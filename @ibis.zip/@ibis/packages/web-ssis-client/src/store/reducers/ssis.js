import { assign, get } from 'lodash';
import openSocket from 'socket.io-client';

const FETCHING_HISTORY = '[ssis] FETCHING_HISTORY';
const FETCH_HISTORY_SUCCESS = '[ssis] FETCH_HISTORY_SUCCESS';
const FETCH_HISTORY_ERROR = '[ssis] FETCH_HISTORY_ERROR';
const FETCHING_ERRORS = '[ssis] FETCHING_ERRORS';
const FETCH_ERRORS_SUCCESS = '[ssis] FETCH_ERRORS_SUCCESS';
const FETCH_ERRORS_ERROR = '[ssis] FETCH_ERRORS_ERROR';
const FETCHING_STATUS = '[ssis] FETCHING_STATUS';
// const FETCH_STATUS_ERROR = '[ssis] FETCH_STATUS_ERROR';

const START_EXECUTION = '[ssis] START_EXECUTION';
const SET_EXECUTION_STATUS = '[ssis] SET_EXECUTION_STATUS';
const START_EXECUTION_ERROR = '[ssis] START_EXECUTION_ERROR';

const initialState = {
  isExecuting: false,
  history: [],
  executionStatus: {},
  executionDetails: {},
  executionErrors: []
};

// region Actions
export const fetchHistory = () => async (dispatch, getState, api) => {
  dispatch({ type: FETCHING_HISTORY });
  try {
    const payload = await api.get('/ssis/execution/history');
    dispatch({
      type: FETCH_HISTORY_SUCCESS,
      payload
    });
  } catch (error) {
    dispatch({
      type: FETCH_HISTORY_ERROR,
      payload: error
    });
  }
};
export const fetchErrors = id => async (dispatch, getState, api) => {
  dispatch({ type: FETCHING_ERRORS });
  try {
    const payload = await api.get(`/ssis/execution/errors/${id}`);
    dispatch({
      type: FETCH_ERRORS_SUCCESS,
      payload
    });
  } catch (error) {
    dispatch({
      type: FETCH_ERRORS_ERROR,
      payload: error
    });
  }
};
export const fetchExecutionStatus = () => async (dispatch, getState, api) => {
  const socket = openSocket('/');

  socket.on('execution-status', payload =>
    dispatch({ type: SET_EXECUTION_STATUS, payload })
  );
  dispatch({ type: FETCHING_STATUS });
  try {
    const payload = await api.get('/ssis/execution/status');
    dispatch({ type: SET_EXECUTION_STATUS, payload });
  } catch (error) {
    dispatch({ type: FETCHING_STATUS, payload: error });
  }
};
export const startExecution = pck => async (dispatch, getState, api) => {
  dispatch({ type: START_EXECUTION });
  try {
    const state = getState();
    const username = get(state, 'auth.user.username', 'ssis-web-client');
    const payload = await api.post(`/ssis/execution/${pck}`, { username });
    dispatch({
      type: SET_EXECUTION_STATUS,
      payload
    });
  } catch (error) {
    dispatch({
      type: START_EXECUTION_ERROR,
      payload: error
    });
  }
};
// endregion name

export default (state = initialState, action) => {
  const { type, payload } = action;
  switch (type) {
    case FETCH_HISTORY_SUCCESS:
      return assign({}, state, {
        error: false,
        fetching: false,
        history: payload
      });
    case FETCHING_HISTORY:
      return assign({}, state, { error: false, fetching: true });
    case FETCH_HISTORY_ERROR:
      return assign({}, state, {
        error: true,
        message: payload,
        history: []
      });
    case FETCH_ERRORS_SUCCESS:
      return assign({}, state, {
        error: false,
        fetching: false,
        executionErrors: payload
      });
    case FETCHING_ERRORS:
      return assign({}, state, {
        error: false,
        fetching: true,
        executionErrors: []
      });
    case FETCH_ERRORS_ERROR:
      return assign({}, state, {
        error: true,
        message: payload,
        executionErrors: []
      });
    case SET_EXECUTION_STATUS:
      const { isExecuting, executionStatus, executionDetails } = payload;
      let found = false;
      const history = state.history.map(item => {
        if (item.execution_id === executionStatus.execution_id) {
          found = true;
          return { ...item, ...executionStatus };
        }
        return item;
      });
      if (!found) {
        history.pop();
        history.unshift(executionStatus);
      }

      return assign({}, state, {
        error: false,
        starting: false,
        isExecuting,
        executionStatus,
        executionDetails,
        history
      });
    case START_EXECUTION:
      return assign({}, state, {
        error: false,
        starting: true,
        executionDetails: {}
      });
    case START_EXECUTION_ERROR:
      return assign({}, state, {
        error: true,
        message: payload,
        starting: false
      });

    default:
      return state;
  }
};
