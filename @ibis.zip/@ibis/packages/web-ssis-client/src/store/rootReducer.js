import { combineReducers } from 'redux';
import { reducer as formReducer } from 'redux-form';
import { auth } from '@nelreina/web-redux';

import env from './reducers/env';
import app from './reducers/app';
import ssis from './reducers/ssis';

export default combineReducers({
  app,
  auth,
  env,
  ssis,
  form: formReducer
});
