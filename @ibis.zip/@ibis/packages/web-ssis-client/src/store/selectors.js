import { createSelector } from 'reselect';
import { find } from 'lodash';
const env = state => state.env.data;
const settings = state => state.app.settings;
const user = state => state.auth.user;

const mapSettings = (env, settings, form = false) => {
  const ret = {};
  const skeys = Object.keys(settings);
  skeys.forEach(sk => {
    const values = form ? {} : [];
    const fkeys = Object.keys(settings[sk].fields);
    fkeys.forEach(fk => {
      const obj = find(env, { name: fk });
      if (form) {
        values[fk] = obj ? obj.value : '';
      } else {
        values.push({
          label: settings[sk].fields[fk].label,
          value: obj ? obj.value : ''
        });
      }
    });
    ret[sk] = {};
    ret[sk]['label'] = settings[sk].label;
    ret[sk]['vendor'] = settings[sk].vendor;
    ret[sk][form ? 'initialValues' : 'data'] = values;
    if (form) {
      ret[sk]['fields'] = settings[sk].fields;
    }
  });
  return ret;
};

const mapSettingsEnvValue = (env, settings) => {
  if (env && env.length > 0) {
    return mapSettings(env, settings);
  } else {
    return {};
  }
};
const initialValuesSettingsForm = (env, settings) => {
  if (env && env.length > 0) {
    return mapSettings(env, settings, true);
  } else {
    return {};
  }
};
const normalizeUser = user => {
  if (!user) return {};
  user['isAdmin'] = user.role === 'admin';
  return user;
};
export const displaySettingsSelector = createSelector(
  env,
  settings,
  mapSettingsEnvValue
);
export const initFormSelector = createSelector(
  env,
  settings,
  initialValuesSettingsForm
);
export const userSelector = createSelector(user, normalizeUser);
