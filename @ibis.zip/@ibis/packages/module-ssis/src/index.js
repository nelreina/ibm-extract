const { invokeSQLCmd, mssqlConn } = require('@nelreina/node-sequelize');
const { find, isArray, isEmpty, each, assign } = require('lodash');
const S = require('string');
const Q = require('./ssis-queries');

const sensitiveValue = '*********';

// region Get Env Vars
const ssisFolder = process.env.SSIS_FOLDER;
const ssisEnv = process.env.SSIS_ENVIRONMENT;
const ssisProject = process.env.SSIS_PROJECT;
const ssisEnvId = process.env.SSIS_ENVIRONMENT_ID;
// endregion

// region Local Methods

const _gracefullend = self =>
  new Promise((resolve, reject) => {
    self._checking = setInterval(async () => {
      self._executionStatus = await _getExecutionStatus(
        self._mssql,
        self._executionId
      );
      self._logger.debug(JSON.stringify(self._executionStatus));
      if (_isExecutionDone(self._executionStatus)) {
        clearInterval(self._checking);
        resolve(true);
      }
    }, 500);
  });

const _executeSSIS = async (mssql, pck) => {
  return await invokeSQLCmd(
    mssql,
    `exec spExecSSIS '${ssisFolder}','${ssisProject}','${pck}.dtsx'`,
    true
  );
};
const _setEnvVariable = async (mssql, name, value) => {
  const expr = `EXEC [SSISDB].[catalog].[set_environment_variable_value] 
      @folder_name=N'${ssisFolder}', 
      @environment_name=N'${ssisEnv}', 
      @variable_name=N'${name}', 
      @value=N'${value}'`;
  await invokeSQLCmd(mssql, expr);
};
const _getExecutionStatus = async (mssql, executionId = null) => {
  const query = { ssisProject, executionId };
  const status = await invokeSQLCmd(
    mssql,
    S(Q.executionStatus).template(query).s,
    true
  );
  const execParamsArray = await invokeSQLCmd(
    mssql,
    S(Q.executionParameters).template({ executionId: status.execution_id }).s
  );
  const params = {};
  execParamsArray.forEach(p => (params[p.name] = p.value));
  status['params'] = params;
  return status;
};
const _getExecutionHistory = async (mssql, executionId = null) => {
  const params = { ssisProject, executionId };
  return await invokeSQLCmd(mssql, S(Q.executionStatus).template(params).s);
};
const _getEventErrors = async (mssql, executionId = null) => {
  const params = { executionId };
  return await invokeSQLCmd(mssql, S(Q.eventErrors).template(params).s);
};
const _isExecutionDone = exec => {
  switch (exec.status) {
    case 3:
    case 4:
    case 6:
    case 7:
    case 9:
      return true;

    default:
      return false;
  }
};
const _setExecutionDetails = (self, details) => {
  if (details.status === 'end') return;
  if (details.data && isEmpty(details.data)) {
    const newStatus = each(
      self._executionDetails,
      item => (item['status'] = details.status)
    );
    self._executionDetails = newStatus;
  } else {
    switch (details.status) {
      case 'pending#5':
        self._executionDetails = details.data;
        break;
      case 'succeeded#7':
        each(self._executionDetails, (item, key) => {
          if (key in details.data) {
            const status = 'succeeded#7';
            self._executionDetails[key] = assign({}, item, details.data[key], {
              status
            });
          }
        });
        break;
      default:
        break;
    }
  }
};
// endregion

class ModuleSSIS {
  constructor(connections, logger) {
    const { io } = connections;
    this._isExecuting = false;
    this._executionStatus = undefined;
    this._executionDetails = {};
    this._executionId = undefined;

    this._io = io;
    this._mssql = mssqlConn(logger);
    this._logger = logger || console;
    this._envVariables = [];
    this._io.on('connection', client => {
      client.emit('execution-status', this.getExecutionStatus());
    });
  }
  async init() {
    const envVarSql = `select * from [SSISDB].[catalog].[environment_variables] where environment_id = ${ssisEnvId}`;
    this._executionStatus = await _getExecutionStatus(this._mssql);
    const env = await invokeSQLCmd(this._mssql, envVarSql);
    if (isArray(env)) {
      this._envVariables = env.map(e => {
        if (e.sensitive) {
          e.value = sensitiveValue;
        }
        return e;
      });
    } else {
      this._logger.error(env);
    }
  }

  getEnvVariables() {
    return this._envVariables;
  }
  async saveEnvVariables(newEnvVar) {
    const keys = Object.keys(newEnvVar);
    const promises = [];
    keys.forEach(name => {
      const env = find(this._envVariables, { name });
      if (env) {
        const value = newEnvVar[name];
        if (env.value !== value) {
          this._logger.info(
            `Saving environment variable: ${name}=${
              env.sensitive ? '******' : value
            }`
          );

          promises.push(_setEnvVariable(this._mssql, name, value));
        }
      }
    });
    const ret = await Promise.all(promises);
    await this.init();
    return this._envVariables;
  }
  async execute(pck, username) {
    if (this._isExecuting) {
      return this.getExecutionStatus();
    }
    // Set job username Execution
    await _setEnvVariable(this._mssql, 'Username', username || 'ssis-user');
    // Start Execution
    const resp = await _executeSSIS(this._mssql, pck);
    this._executionId = resp && resp.execution_id;
    this._isExecuting = true;
    this._executionStatus = await _getExecutionStatus(
      this._mssql,
      this._executionId
    );
    this._executionDetails = {};
    this.broadcastStatus();
    this._logger.info(JSON.stringify(this._executionStatus));
    return this.getExecutionStatus();
  }
  isExecuting() {
    return this._isExecuting;
  }

  async getExecutionHistory() {
    return await _getExecutionHistory(this._mssql);
  }
  async getEventErrors(executionId) {
    return await _getEventErrors(this._mssql, executionId);
  }
  getExecutionStatus() {
    return {
      isExecuting: this._isExecuting,
      executionStatus: this._executionStatus,
      executionDetails: this._executionDetails
    };
  }
  async setExecutionDetails(details) {
    this._logger.info(JSON.stringify(details));
    await this.prepareBroadcastMessage(details);
    this.broadcastStatus();
    return 'OK';
  }
  async prepareBroadcastMessage(details) {
    this._executionStatus = await _getExecutionStatus(
      this._mssql,
      this._executionId
    );
    _setExecutionDetails(this, details);
    if (details.status === 'end') {
      await _gracefullend(this);
      this._logger.info(JSON.stringify(this._executionStatus));
      this._isExecuting = false;
    }
  }
  broadcastStatus() {
    this._io.sockets.emit('execution-status', this.getExecutionStatus());
  }
}
module.exports = ModuleSSIS;
