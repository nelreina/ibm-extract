const runExctract = require('./lib');

const tables = require('../tables.json');

(async () => {
  const ret = await runExctract(tables);
  console.info(ret);
})();
