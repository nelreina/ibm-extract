const fs = require('fs');
const crypto = require('crypto');
const algorithm = 'aes-256-ctr';
const salt = 'd6F3Efeq';
const odbc = require('odbc')();

exports.invokeSQLCmd = async (db, query, returnObject = false) => {
  let result;
  try {
    result = await db.query(query, { type: db.QueryTypes.SELECT });
    if (returnObject) {
      result = result.length > 0 ? result[0] : {};
    }
  } catch (error) {
    const { message, name } = error;
    result = { message, name };
    // result = error;
  }
  return result;
};
exports.bulkInsert = async (db, tableName, filename, del = ',') => {
  const sqlstmt = `BULK INSERT ${tableName} FROM '${filename}' 
        WITH (FIRSTROW=2, FIELDTERMINATOR='${del}',ROWTERMINATOR='\\n')`;
  const ret = await db.query(sqlstmt, { type: db.QueryTypes.INSERT });
  let obj = {};
  obj[tableName] = ret[1] ? ret[1] : 0;
  return obj;
  // return ret;
};
exports.writeFile = (fileName, content) =>
  new Promise((resolve, reject) => {
    fs.writeFile(fileName, content, err => {
      if (err) reject(err);
      resolve(`${fileName} created!`);
    });
  });

exports.encrypt = text => {
  var cipher = crypto.createCipher(algorithm, salt);
  var crypted = cipher.update(text, 'utf8', 'hex');
  crypted += cipher.final('hex');
  return crypted;
};

exports.decrypt = text => {
  var decipher = crypto.createDecipher(algorithm, salt);
  var dec = decipher.update(text, 'hex', 'utf8');
  dec += decipher.final('utf8');
  return dec;
};

exports.odbcExecQuery = (conn, tableName, columns, limit) =>
  new Promise((resolve, reject) => {
    let sqlstmt = 'select ';
    sqlstmt += columns ? columns : '*';
    sqlstmt += ` from ${tableName}`;
    sqlstmt += limit ? ` FETCH FIRST ${limit} ROWS ONLY` : '';

    odbc.open(conn, async err => {
      if (err) return reject(err);
      console.info(sqlstmt);
      console.time(tableName);
      odbc.query(sqlstmt, (err, data) => {
        if (err) return reject(err);
        return resolve(data);
      });
      // odbc.close(function() {
      //   console.log('done');
      //   console.timeEnd(tableName);
      // });
    });
  });

// console.log('encrypt', encrypt(''));
// console.log('decrypt', decrypt(''));
