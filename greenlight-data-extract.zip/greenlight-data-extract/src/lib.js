require('dotenv').config();
const converter = require('json2csv');
const Sequelize = require('sequelize');
const path = require('path');
const {
  invokeSQLCmd,
  bulkInsert,
  odbcExecQuery,
  writeFile,
  decrypt
} = require('./util');
const { extract } = require('./lib');

const sqlHost = process.env.SQL_HOST;
const sqlDialect = process.env.SQL_DIALECT;
const sqlDB = process.env.SQL_DATABASE;
const sqlUser = process.env.SQL_USER;
const sqlPsw = decrypt(process.env.SQL_PASSWORD);
let dirData = process.env.DIR_DATA || path.resolve(__dirname, `../data`);

const lib = process.env.IBM_LIB;
const dns = process.env.IBM_DNS;
const user = process.env.IBM_USER;
const password = decrypt(process.env.IBM_PASSWORD);
const IBM = `DSN=${dns};Uid=${user};Pwd=${password};`;

const options = {
  host: sqlHost,
  dialect: sqlDialect,
  operatorsAliases: false
  // logging: false
};

dirData = path.normalize(dirData);
const mssql = new Sequelize(sqlDB, sqlUser, sqlPsw, options);

const exctract = async (table, IBM, mssql, dirData) => {
  const { tableName, columns, limit } = table;
  console.time(tableName);
  console.info(`Starting importing ${tableName}...`);
  const quotes = '';
  const del = '|';
  const filename = `${dirData}\\${tableName}.csv`;
  await invokeSQLCmd(mssql, `delete from ${tableName}`);
  const data = await odbcExecQuery(IBM, `${lib}.${tableName}`, columns, limit);

  const csv = converter({ data, quotes, del });

  let res = await writeFile(filename, csv);
  console.info(res);
  try {
    res = await bulkInsert(mssql, tableName, filename, del);
    return res;
  } catch (error) {
    return error;
  }
  console.timeEnd(tableName);
};

module.exports = async tables => {
  const promises = [];
  tables.forEach(table => {
    promises.push(exctract(table, IBM, mssql, dirData));
  });
  const ret = await Promise.all(promises);
  mssql.close();
  return ret;
};
