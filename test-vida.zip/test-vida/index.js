require('dotenv').config();

const db = require('odbc')();
const crypto = require('crypto');
const tables = ['SPRPWH00P', 'SPRPWH00P'];

const algorithm = 'aes-256-ctr',
  salt = 'd6F3Efeq';

function encrypt(text) {
  var cipher = crypto.createCipher(algorithm, salt);
  var crypted = cipher.update(text, 'utf8', 'hex');
  crypted += cipher.final('hex');
  return crypted;
}

function decrypt(text) {
  var decipher = crypto.createDecipher(algorithm, salt);
  var dec = decipher.update(text, 'hex', 'utf8');
  dec += decipher.final('utf8');
  return dec;
}

const query = (db, sql) =>
  new Promise((resolve, reject) => {
    db.query(sql, (err, data) => {
      if (err) return reject(err);
      return resolve(data);
    });
  });

const lib = process.env.IBM_LIB;
const dns = process.env.IBM_DNS;
const user = process.env.IBM_USER;
const password = decrypt(process.env.IBM_PASSWORD);

const cn = `DSN=${dns};Uid=${user};Pwd=${password};`;
// console.info(cn);
// console.log('encrypt', encrypt(''));
// console.log('decrypt', decrypt(''));

db.open(cn, async err => {
  if (err) return console.log(err);
  console.info('Connected to ODBC');
  // tables.forEach;
  console.time('sqlquery');
  const promises = [];

  tables.forEach(table => {
    promises.push(query(db, `select count(*) ${table} from ${lib}.${table}`));
  });
  const data = await Promise.all(promises);
  console.info(data);
  console.timeEnd('sqlquery');

  db.close(function() {
    console.log('done');
  });
});
